#include <jni.h>
#include <string>
#include <android/log.h>
#include <dlfcn.h>

#define TAG        "mikrom"
#define LOG_PRIORITY   ANDROID_LOG_INFO
#define ALOGI(fmt, ...) __android_log_print(LOG_PRIORITY, TAG, fmt, ##__VA_ARGS__)

typedef const char* (*kbacktraceFunc)(bool with_context,const char* moduleName);


void* get_handle(const char* libname) {
    FILE* fp = fopen("/proc/self/maps", "r");
    if (fp == nullptr) return nullptr;

    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        uintptr_t start, end;
        char perm[5], offset[20], device[6], inode[10], pathname[1024];
        int n = sscanf(line, "%lx-%lx %4s %lx %5s %9s %1023s\n", &start, &end, perm, &offset, device, inode, pathname);
        if (n < 7) continue;
        // 检查是否是目标共享库
        if (strstr(pathname, libname)) {
            fclose(fp);
            return reinterpret_cast<void*>(start); // 获取共享库的句柄
        }
    }
    fclose(fp);
    return nullptr;
}


void showBacktrace(const char* moduleName){
    void* handle_kbacktrace=NULL;
#if defined(__aarch64__)
    // 当前 CPU 架构为 arm64
    handle_kbacktrace= dlopen("/system/lib64/libkbacktrace.so",RTLD_NOW);
#else
    // 当前 CPU 架构为 armeabi-v7a 或更早版本
    handle_kbacktrace= dlopen("/system/lib/libkbacktrace.so",RTLD_NOW);
#endif
    if (handle_kbacktrace == NULL) {
        const char* error = dlerror();
        ALOGI("not found so.%s",error);
        return ;
    }

    void* handle = get_handle("libkbacktrace.so");
    ALOGI("handle_kbacktrace:%p handle:%p",handle_kbacktrace,handle);
    ALOGI("load so success.");
    kbacktraceFunc kbacktrace = (kbacktraceFunc)dlsym(handle_kbacktrace, "_Z10kbacktracebPKc");
    if(kbacktrace==NULL){
        const char* error = dlerror();
        ALOGI("not found method.%s",error);
        return;
    }
    const char* res=kbacktrace(true,moduleName);
    ALOGI("%s\n",res);
}

extern "C" JNIEXPORT jstring JNICALL
Java_cn_rom_backtracedemo_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    showBacktrace("");
    return env->NewStringUTF(hello.c_str());
}