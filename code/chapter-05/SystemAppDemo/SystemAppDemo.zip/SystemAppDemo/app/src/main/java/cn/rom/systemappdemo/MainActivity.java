package cn.rom.systemappdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.io.File;
import java.io.RandomAccessFile;

public class MainActivity extends AppCompatActivity {

    public String writeTxtToFile(String strContent, String filePath, String fileName) {
        String strFilePath = filePath+fileName;
        try {
            File file = new File(strFilePath);
            if (!file.exists()) {
                file.getParentFile().mkdirs();
                file.createNewFile();
            }
            RandomAccessFile raf = new RandomAccessFile(file, "rwd");
            raf.setLength(0);
            long writePosition = raf.getFilePointer();
            raf.seek(writePosition);
            raf.write(strContent.getBytes());
            raf.close();
            //
        } catch (Exception e) {
            Log.e("MainActivity", "Error on write File:" + e);
            return e.getMessage();
        }
        return "";
    }
    TextView txtContext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtContext=findViewById(R.id.txtContext);
        String errMsg= writeTxtToFile("测试内置系统App","/data/system/","demo.txt");
        if(errMsg.isEmpty()){
            txtContext.setText("写入成功");
        }else{
            txtContext.setText("写入失败,"+errMsg);
        }
    }
}