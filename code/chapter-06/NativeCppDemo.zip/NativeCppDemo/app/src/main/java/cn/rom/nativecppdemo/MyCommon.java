package cn.rom.nativecppdemo;


import android.util.Log;

public class MyCommon {
    public static String getMyJarVer(){
        return "v1.0";
    }
    public static int add(int a,int b){
        return a+b;
    }
    public static void injectJar(){
        Log.i("MyCommon","injectJar enter");
    }
}
